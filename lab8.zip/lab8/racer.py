import pygame
import random

pygame.init()

screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Racer")

white = (255, 255, 255)
black = (0, 0, 0)
yellow = (255, 255, 0)

font = pygame.font.SysFont(None, 30)

clock = pygame.time.Clock()

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(white)
        self.rect = self.image.get_rect()
        self.rect.center = (screen_width // 2, screen_height - 50)
        self.speed = 5

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        self.check_boundaries()

    def check_boundaries(self):
        if self.rect.left <= 0:
            self.rect.left = 0
        elif self.rect.right >= screen_width:
            self.rect.right = screen_width

class Coin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill(yellow)
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = random.randint(-1000, -100)

    def update(self):
        self.rect.y += 5 

all_sprites = pygame.sprite.Group()
coins_group = pygame.sprite.Group()

player = Player()
all_sprites.add(player)

def create_coin():
    coin = Coin()
    all_sprites.add(coin)
    coins_group.add(coin)

running = True
collected_coins = 0
while running:
    screen.fill(black)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if random.random() < 0.02:
        create_coin()

    all_sprites.update()

    collected = pygame.sprite.spritecollide(player, coins_group, True)
    collected_coins += len(collected)

    all_sprites.draw(screen)

    coin_text = font.render("Coins: " + str(collected_coins), True, white)
    screen.blit(coin_text, (screen_width - coin_text.get_width() - 10, 10))

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
