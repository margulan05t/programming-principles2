import re

def text_match(text):
    patterns = '^a(b*)$'
    if re.search(patterns, text):
        return 'Found a match!'
    else:
        return 'Not matched!'
    
txt = input("Enter text: ")
print(text_match(txt))
