import re

def find_sequences(text):
    pattern = r'\b[A-Z][a-z]+\b'
    sequences = re.findall(pattern, text)
    return sequences

def main():
    text = input("Enter text: ")
    sequences = find_sequences(text)
    if sequences:
        print("Sequences found:")
        for seq in sequences:
            print(seq)
    else:
        print("No sequences found.")

if __name__ == "__main__":
    main()
