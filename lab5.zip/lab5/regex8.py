import re

def split_at_uppercase(input_string):
    # Use regular expression to split at uppercase letters
    return re.findall('[A-Z][^A-Z]*', input_string)

def main():
    input_string = input("Enter a string: ")
    result = split_at_uppercase(input_string)
    print("Split result:", result)

if __name__ == "__main__":
    main()
