import re

def insert_spaces(input_string):
    # Use regular expression to insert spaces before words starting with capital letters
    return re.sub(r'([a-z])([A-Z])', r'\1 \2', input_string)

def main():
    input_string = input("Enter a string: ")
    result = insert_spaces(input_string)
    print("Modified string:", result)

if __name__ == "__main__":
    main()
