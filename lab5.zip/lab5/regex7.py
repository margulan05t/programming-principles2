def snake_to_camel(snake_case):
    words = snake_case.split('_')
    camel_case = words[0] + ''.join(word.capitalize() for word in words[1:])
    return camel_case

def main():
    snake_case = input("Enter snake case string: ")
    camel_case = snake_to_camel(snake_case)
    print("Camel case:", camel_case)

if __name__ == "__main__":
    main()
