import re

def match_pattern(text):
    pattern = r'a(bb{2,3})'
    match = re.search(pattern, text)
    if match:
        print("Match found:", match.group())
    else:
        print("No match found.")

txt = input("Enter text:")
match_pattern(txt)  # Здесь вызываем функцию match_pattern с введенным текстом
