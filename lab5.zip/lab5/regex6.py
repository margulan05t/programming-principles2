import re

def replace_characters(text):
    pattern = r'[ ,.]'
    replaced_text = re.sub(pattern, ':', text)
    return replaced_text

def main():
    text = input("Enter text: ")
    replaced_text = replace_characters(text)
    print("Original text:", text)
    print("Replaced text:", replaced_text)

if __name__ == "__main__":
    main()

