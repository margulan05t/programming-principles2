import pygame
import random

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Snake")

# Set up colors
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
red = (255, 0, 0)

# Set up fonts
font = pygame.font.SysFont(None, 30)

# Set up clock
clock = pygame.time.Clock()

# Snake class
class Snake:
    def __init__(self):
        self.size = 1
        self.elements = [[100, 50]]
        self.radius = 10
        self.dx = 5
        self.dy = 0

    def draw(self):
        for element in self.elements:
            pygame.draw.circle(screen, green, element, self.radius)

    def move(self):
        if self.size > 1:
            for i in range(self.size - 1, 0, -1):
                self.elements[i] = list(self.elements[i - 1])
        self.elements[0][0] += self.dx
        self.elements[0][1] += self.dy

    def add_element(self):
        self.elements.append(list(self.elements[-1]))

    def collision_with_food(self, food_x, food_y):
        if food_x - self.radius < self.elements[0][0] < food_x + self.radius \
                and food_y - self.radius < self.elements[0][1] < food_y + self.radius:
            return True
        return False

    def collision_with_wall(self):
        if not 0 < self.elements[0][0] < screen_width \
                or not 0 < self.elements[0][1] < screen_height:
            return True
        return False

    def collision_with_self(self):
        for i in range(1, self.size):
            if self.elements[0] == self.elements[i]:
                return True
        return False

# Food class
class Food:
    def __init__(self):
        self.x = random.randrange(0, screen_width - 20, 20)
        self.y = random.randrange(0, screen_height - 20, 20)
        self.timer = 300  # Time until food disappears (300 frames at 60 fps)

    def draw(self):
        pygame.draw.rect(screen, red, (self.x, self.y, 20, 20))

    def update_timer(self):
        self.timer -= 1

# Function to generate food
def generate_food():
    return Food()

# Snake and food objects
snake = Snake()
foods = []

# Game loop
running = True
while running:
    screen.fill(black)

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and snake.dy == 0:
                snake.dx = 0
                snake.dy = -5
            elif event.key == pygame.K_DOWN and snake.dy == 0:
                snake.dx = 0
                snake.dy = 5
            elif event.key == pygame.K_LEFT and snake.dx == 0:
                snake.dx = -5
                snake.dy = 0
            elif event.key == pygame.K_RIGHT and snake.dx == 0:
                snake.dx = 5
                snake.dy = 0

    # Move snake
    snake.move()

    # Check collision with wall
    if snake.collision_with_wall():
        running = False

    # Check collision with self
    if snake.collision_with_self():
        running = False

    # Check collision with food
    for food in foods:
        if snake.collision_with_food(food.x, food.y):
            snake.add_element()
            foods.remove(food)
            foods.append(generate_food())

    # Draw snake
    snake.draw()

    # Draw and update food
    for food in foods:
        food.draw()
        food.update_timer()
        if food.timer == 0:
            foods.remove(food)
            foods.append(generate_food())

    pygame.display.flip()
    clock.tick(60)

# Quit pygame
pygame.quit()
