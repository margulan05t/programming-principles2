import pygame
import random

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Racer")

# Set up colors
white = (255, 255, 255)
black = (0, 0, 0)

# Set up fonts
font = pygame.font.SysFont(None, 30)

# Set up clock
clock = pygame.time.Clock()

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(white)
        self.rect = self.image.get_rect()
        self.rect.center = (screen_width // 2, screen_height - 50)
        self.speed = 5

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        self.check_boundaries()

    def check_boundaries(self):
        if self.rect.left <= 0:
            self.rect.left = 0
        elif self.rect.right >= screen_width:
            self.rect.right = screen_width

# Coin class
class Coin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((20, 20))
        self.image.fill((255, 215, 0))  # Yellow
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = random.randint(-1000, -100)

    def update(self):
        self.rect.y += 5  # Fall speed

# Enemy class
class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill((255, 0, 0))  # Red
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, screen_width - self.rect.width)
        self.rect.y = random.randint(-1000, -100)
        self.speed = 3

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > screen_height:
            self.rect.x = random.randint(0, screen_width - self.rect.width)
            self.rect.y = random.randint(-1000, -100)

# Group for all sprites
all_sprites = pygame.sprite.Group()
coins_group = pygame.sprite.Group()
enemies_group = pygame.sprite.Group()

# Create player
player = Player()
all_sprites.add(player)

# Function to create new coins
def create_coin():
    coin = Coin()
    all_sprites.add(coin)
    coins_group.add(coin)

# Function to create new enemies
def create_enemy():
    enemy = Enemy()
    all_sprites.add(enemy)
    enemies_group.add(enemy)

# Game loop
running = True
coin_count = 0  # Counter for the number of collected coins
enemy_speed_increase = 5  # Increase in enemy speed when collecting N coins
while running:
    screen.fill(black)

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Create new coins randomly
    if random.random() < 0.02:
        create_coin()

    # Create new enemies randomly
    if random.random() < 0.01:
        create_enemy()

    # Update sprites
    all_sprites.update()

    # Check collision between player and coins
    collected_coins = pygame.sprite.spritecollide(player, coins_group, True)
    for coin in collected_coins:
        coin_count += 1
        if coin_count % enemy_speed_increase == 0:
            for enemy in enemies_group:
                enemy.speed += 1  # Increase enemy speed

    # Draw sprites
    all_sprites.draw(screen)

    # Display coin count
    coin_text = font.render("Coins: " + str(coin_count), True, white)
    screen.blit(coin_text, (10, 10))

    pygame.display.flip()
    clock.tick(60)

# Quit pygame
pygame.quit()
