import pygame

# Initialize pygame
pygame.init()

# Set up the screen
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Rhombus")

# Set up colors
white = (255, 255, 255)
black = (0, 0, 0)

# Function to draw rhombus
def draw_rhombus(center, width, height):
    # Calculate the vertices of the rhombus
    x, y = center
    vertices = [(x - width // 2, y), (x, y - height // 2), (x + width // 2, y), (x, y + height // 2)]
    pygame.draw.polygon(screen, white, vertices)

# Game loop
running = True
while running:
    screen.fill(black)

    # Draw a rhombus
    draw_rhombus((screen_width // 2, screen_height // 2), 100, 150)

    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Continuously update the screen
    pygame.display.flip()

# Quit pygame
pygame.quit()
