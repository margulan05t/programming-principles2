import datetime
dt = datetime.datetime.today().replace(microsecond=0)
print()
print(dt)
print()
