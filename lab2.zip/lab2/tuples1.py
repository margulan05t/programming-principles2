fruits = ("apple", "banana", "cherry")
print(fruits[0])