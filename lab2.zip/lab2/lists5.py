fruits = ["apple", "banana", "cherry"]
fruits.remove("banana")