a = 50
b = 10
if a != b:
  print("Hello World")