i = 1
while i < 6:
  if i == 3:
    break
  i += 1