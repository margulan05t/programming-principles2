a = 50
b = 10
if a == b:
  print("1")
elif a > b:
  print("2")
else:
  print("3")