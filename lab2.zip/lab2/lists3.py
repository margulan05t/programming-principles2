fruits =["apple", "banana", "cherry"]
fruits.append("orange")