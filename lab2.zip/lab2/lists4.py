fruits = ["aplle", "banana", "cherry"]
fruits.insert(1, "lemon")