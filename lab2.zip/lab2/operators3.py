fruits = ["apple", "banana"]
if "apple" in fruits:
  print("Yes, apple is a fruit!")