fruits = {"apple", "banana", "cherry"}
fruits.remove("banana")
print(fruits)