if 5 > 2:
    print("YES")
