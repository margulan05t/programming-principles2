a=6
b=6
c=8
d=8
if a==b and c==d:
  print("Hello")