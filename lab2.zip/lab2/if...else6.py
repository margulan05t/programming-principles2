a=10
b=10
c=5
d=5
if a == b or c == d:
  print("Hello")