fruits = {"apple", "banana", "cherry"}
fruits.discard("banana")
print(fruits)