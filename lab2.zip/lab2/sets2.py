fruits = {"apple", "banana", "cherry"}
fruits.add("orange")
print(fruits)