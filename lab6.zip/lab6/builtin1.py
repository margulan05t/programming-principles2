from functools import reduce
import operator

def multiply_numbers(numbers):
    if not numbers:
        return None 
    return reduce(operator.mul, numbers)

def main():
    numbers = [int(x) for x in input("Enter numbers separated by space: ").split()]
    result = multiply_numbers(numbers)
    if result is None:
        print("No numbers provided or the list is empty.")
    else:
        print("Result of multiplying all numbers:", result)

if __name__ == "__main__":
    main()
