def count_lines(file_path):
    try:
        with open(file_path, 'r') as file:
            line_count = sum(1 for line in file)
        return line_count
    except FileNotFoundError:
        print("File not found.")
        return -1

def main():
    file_path = input("Enter the path to the text file: ")
    line_count = count_lines(file_path)
    if line_count != -1:
        print(f"Number of lines in the file: {line_count}")

if __name__ == "__main__":
    main()
