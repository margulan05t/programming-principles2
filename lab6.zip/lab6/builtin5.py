def all_true(elements):
    return all(elements)

def main():
    my_tuple = (True, True, False, True)
    result = all_true(my_tuple)
    if result:
        print("All elements of the tuple are true.")
    else:
        print("Not all elements of the tuple are true.")

if __name__ == "__main__":
    main()
