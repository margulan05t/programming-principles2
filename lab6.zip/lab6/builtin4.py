import time
import math

def delayed_sqrt(number, milliseconds):
    time.sleep(milliseconds / 1000) 
    result = math.sqrt(number)
    return result

def main():
    number = int(input("Enter a number: "))
    milliseconds = int(input("Enter milliseconds to wait: "))
    result = delayed_sqrt(number, milliseconds)
    print(f"Square root of {number} after {milliseconds} milliseconds is {result}")

if __name__ == "__main__":
    main()
