def copy_file(source_file, destination_file):
    try:
        with open(source_file, 'r') as source:
            with open(destination_file, 'w') as destination:
                for line in source:
                    destination.write(line)
        print("File copied successfully.")
    except FileNotFoundError:
        print("Source file not found.")
    except IOError:
        print("Error copying file.")

def main():
    source_file = input("Enter the path to the source file: ")
    destination_file = input("Enter the path to the destination file: ")
    copy_file(source_file, destination_file)

if __name__ == "__main__":
    main()
