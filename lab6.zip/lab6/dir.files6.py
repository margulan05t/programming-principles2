import string

def generate_files():
    for letter in string.ascii_uppercase:
        file_name = letter + ".txt"
        with open(file_name, 'w') as file:
            file.write(f"This is the content of {file_name}")

def main():
    generate_files()
    print("Files generated successfully.")

if __name__ == "__main__":
    main()
