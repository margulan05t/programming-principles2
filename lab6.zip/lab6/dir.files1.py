import os

def list_directories(path):
    directories = [dir_name for dir_name in os.listdir(path) if os.path.isdir(os.path.join(path, dir_name))]
    return directories

def list_files(path):
    files = [file_name for file_name in os.listdir(path) if os.path.isfile(os.path.join(path, file_name))]
    return files

def list_all_contents(path):
    all_contents = os.listdir(path)
    return all_contents

def main():
    path = input("Enter the path: ")

    print("\nList of directories:")
    directories = list_directories(path)
    for directory in directories:
        print(directory)

    print("\nList of files:")
    files = list_files(path)
    for file in files:
        print(file)

    print("\nList of all directories and files:")
    all_contents = list_all_contents(path)
    for content in all_contents:
        print(content)

if __name__ == "__main__":
    main()
