import pygame

pygame.init()
clock = pygame.time.Clock()

screen = pygame.display.set_mode((400, 400))
pygame.display.set_caption("Yandex Music")

Yandex = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\Без названия.png")
Music = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\Без названия.jpeg")

Song1 = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\Без названия.png")

image_list = [
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\effbbbdf75ed154b53443babbbe6c4c3_large.png"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\kairat-nurtas-bay-a.jpg"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\hqdefault.jpg"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\f75863f1706d418e9aaf5eeee393a204_464_464.jpg"),
]
image_list2 = [
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\effbbbdf75ed154b53443babbbe6c4c3_large.png"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\kairat-nurtas-bay-a.jpg"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\hqdefault.jpg"),
    pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\f75863f1706d418e9aaf5eeee393a204_464_464.jpg"),
]


song_list = [
   "C:\\Users\\margu\\Downloads\\eminem_-_mockingbird_(muztune.me).mp3",
    "C:\\Users\\margu\\Downloads\\Қайрат Нұртас - Байқа (2016).mp3",
    "C:\\Users\\margu\\Downloads\\nick-cave-the-bad-seeds-loverman-2011-remastered-version-2011-remastered-version_(zzz.fm).mp3",
    "C:\\Users\\margu\\Downloads\\OST Game of Thrones - Main Theme.mp3"
]

running = True
current_image_index = 2  # Установка начального изображения
current_song_index = 2    # Установка начальной песни

while running:
    screen.fill((255, 255, 255))
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RETURN]:
        screen.blit(Music, (100, 200))
        screen.blit(Yandex, (30, 450))
        pygame.display.update()
        current_image_index = 0
        current_image = Song1
        pygame.mixer.music.stop()
        pygame.mixer.music.load(song_list[current_song_index])
        pygame.mixer.music.play()
        screen.blit(current_image, (0, 0))
        pygame.display.update()
    elif keys[pygame.K_LEFT]:
        current_song_index = (current_song_index - 1) % len(song_list)
        current_image_index = current_song_index
        current_image = image_list[current_image_index]
        pygame.mixer.music.stop()
        pygame.mixer.music.load(song_list[current_song_index])
        pygame.mixer.music.play()
        screen.blit(current_image, (0, 0))
        pygame.display.update()
    elif keys[pygame.K_RIGHT]:
        current_song_index = (current_song_index + 1) % len(song_list)
        current_image_index = current_song_index
        current_image = image_list[current_image_index]
        pygame.mixer.music.stop()
        pygame.mixer.music.load(song_list[current_song_index])
        pygame.mixer.music.play()
        screen.blit(current_image, (0, 0))
        pygame.display.update()
        
    elif keys[pygame.K_UP]:  # Остановить музыку
        pygame.mixer.music.pause()
        current_image = image_list2[current_image_index]
        screen.blit(current_image, (0, 0))
        pygame.display.update()
    elif keys[pygame.K_DOWN]:  # Возобновить музыку
        pygame.mixer.music.unpause()
        current_image = image_list[current_image_index]
        screen.blit(current_image, (0, 0))
        pygame.display.update()
    clock.tick(9)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

pygame.quit()
