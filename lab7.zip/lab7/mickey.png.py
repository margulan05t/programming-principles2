import pygame
import sys
from datetime import datetime
import math 

pygame.init()

width, height = 800, 800
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Mickey Mouse Clock")

mickey_clock_image = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\clock\\mm.png") 
mickey_seconds_hand_image = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\clock\\left.png")
mickey_minutes_hand_image = pygame.image.load("C:\\Users\\margu\\OneDrive\\Документы\\lab7\\clock\\right.png")

mickey_clock_rect = mickey_clock_image.get_rect(center=(width // 2, height // 2))
mickey_seconds_hand_rect = mickey_seconds_hand_image.get_rect(center=(width // 2, height // 2))
mickey_minutes_hand_rect = mickey_minutes_hand_image.get_rect(center=(width // 2, height // 2))

def draw_hands(surface, angle, image, rect):
    rotated_image = pygame.transform.rotate(image, -angle)
    rotated_rect = rotated_image.get_rect(center=rect.center)
    surface.blit(rotated_image, rotated_rect)

running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    current_time = datetime.now()
    seconds_angle = (current_time.second / 60) * 360 
    minutes_angle = (current_time.minute / 60) * 360 + (current_time.second / 60) * 6  

    window.fill((255, 255, 255))
    window.blit(mickey_clock_image, mickey_clock_rect)

    draw_hands(window, seconds_angle, mickey_seconds_hand_image, mickey_seconds_hand_rect)
    draw_hands(window, minutes_angle, mickey_minutes_hand_image, mickey_minutes_hand_rect)

    pygame.display.flip()

    clock.tick(60)

pygame.quit()
sys.exit()


